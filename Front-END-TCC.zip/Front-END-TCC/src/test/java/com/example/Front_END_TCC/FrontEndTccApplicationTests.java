package com.example.Front_END_TCC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontEndTccApplicationTests {

	@Test
	void contextLoads() {
	}

}
