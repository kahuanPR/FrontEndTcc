package com.example.Front_END_TCC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontEndTccApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontEndTccApplication.class, args);
	}

}
